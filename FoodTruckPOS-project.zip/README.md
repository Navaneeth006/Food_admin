# FoodTruckPOS

Android + local Node.js POS architecture for an iPad kiosk, PhonePe payments, and ESC/POS printing.

IMPORTANT:
- This is a project scaffold, not a tested production APK.
- PhonePe credentials must be configured separately.
- The embedded Node runtime must be validated against the selected Android Node runtime before production use.
- Never commit real PhonePe secrets.

## GitHub build
1. Upload the entire project to GitHub.
2. Open Actions.
3. Select `Build Android APK`.
4. Run workflow.
5. Download the `FoodTruckPOS-debug` artifact.

## Local Android build
Open the `android` folder in Android Studio and build the debug APK.

## PhonePe
Copy `phonepe/.env.example` to the runtime configuration mechanism you choose and fill in merchant credentials.
