package com.foodtruck.pos

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val status = findViewById<TextView>(R.id.tvStatus)
        val url = findViewById<TextView>(R.id.tvUrl)
        val toggle = findViewById<Button>(R.id.btnToggle)
        val kiosk = findViewById<Button>(R.id.btnOpenKiosk)

        fun refresh() {
            val ip = NetworkUtils.getLocalIpAddress(this)
            status.text = if (running) "Server: RUNNING" else "Server: STOPPED"
            url.text = if (running) "http://$ip:4242/" else "--"
            toggle.text = if (running) "Stop Server" else "Start Server"
        }

        toggle.setOnClickListener {
            val intent = Intent(this, NodeServerService::class.java)
            if (!running) {
                ContextCompat.startForegroundService(this, intent)
                running = true
            } else {
                stopService(intent)
                running = false
            }
            refresh()
        }

        kiosk.setOnClickListener {
            val ip = NetworkUtils.getLocalIpAddress(this)
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://$ip:4242/")))
        }

        refresh()
    }
}
