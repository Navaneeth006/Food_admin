package com.foodtruck.pos

import android.app.Application

class PosApplication : Application()
