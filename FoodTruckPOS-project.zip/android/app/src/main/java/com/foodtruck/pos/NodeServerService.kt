package com.foodtruck.pos

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class NodeServerService : Service() {

    companion object {
        private const val CHANNEL = "FoodTruckPOS"
        private const val NOTIFICATION_ID = 4242
    }

    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL,
                "Food Truck POS Server",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ip = NetworkUtils.getLocalIpAddress(this)

        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Food Truck POS Server")
            .setContentText("Kiosk: http://$ip:4242")
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        // TODO:
        // Start the embedded Node.js runtime here after selecting and
        // packaging a compatible Android Node runtime.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        // TODO: cleanly stop the embedded Node runtime.
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
