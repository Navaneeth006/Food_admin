package com.foodtruck.pos

import android.content.Context
import android.net.wifi.WifiManager

object NetworkUtils {
    fun getLocalIpAddress(context: Context): String {
        return try {
            val wm = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            if (ip == 0) "127.0.0.1"
            else String.format(
                "%d.%d.%d.%d",
                ip and 0xff,
                ip shr 8 and 0xff,
                ip shr 16 and 0xff,
                ip shr 24 and 0xff
            )
        } catch (_: Exception) {
            "127.0.0.1"
        }
    }
}
