package com.foodtruck.pos

/**
 * Bluetooth ESC/POS printer integration point.
 *
 * Production implementation should:
 * 1. request Android Bluetooth permissions on Android 12+
 * 2. discover/select a paired printer
 * 3. open an RFCOMM connection
 * 4. send ESC/POS bytes
 * 5. handle reconnect and printer errors
 */
class PrinterManager
