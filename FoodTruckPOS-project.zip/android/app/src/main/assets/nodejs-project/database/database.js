// SQLite database integration point.
// Add a supported Android-compatible SQLite driver/runtime here.
module.exports = {};
