let cart = [];

async function loadProducts() {
  const el = document.getElementById("menu");
  try {
    const r = await fetch("/api/products");
    const products = await r.json();

    if (!products.length) {
      el.innerHTML = "<p>No products configured yet.</p>";
      return;
    }

    el.innerHTML = products.map(p =>
      `<button onclick='add(${JSON.stringify(p)})'>${p.name} - ₹${(p.price/100).toFixed(2)}</button>`
    ).join("<br><br>");
  } catch (e) {
    el.textContent = "Unable to contact POS server.";
  }
}

function add(product) {
  cart.push(product);
  renderCart();
}

function renderCart() {
  const el = document.getElementById("cart");
  const pay = document.getElementById("pay");

  if (!cart.length) {
    el.textContent = "Cart is empty";
    pay.disabled = true;
    return;
  }

  const total = cart.reduce((s, p) => s + Number(p.price || 0), 0);
  el.innerHTML = cart.map(p => `<div>${p.name}</div>`).join("");
  el.innerHTML += `<hr><strong>Total ₹${(total/100).toFixed(2)}</strong>`;
  pay.disabled = false;
}

document.getElementById("pay").onclick = async () => {
  alert("Connect the PhonePe merchant configuration before accepting payments.");
};

loadProducts();
