// ESC/POS printer integration point.
// Android Bluetooth permissions and the native bridge must be implemented.
module.exports = {};
