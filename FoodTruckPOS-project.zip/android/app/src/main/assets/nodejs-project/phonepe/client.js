/*
Official SDK integration point.

The official PhonePe Node SDK package is:
@phonepe-pg/pg-sdk-node

Configure:
PHONEPE_CLIENT_ID
PHONEPE_CLIENT_SECRET
PHONEPE_CLIENT_VERSION
PHONEPE_ENV

Do not place real secrets in source control.
*/
module.exports = null;
