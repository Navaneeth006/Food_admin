const express = require("express");
const http = require("http");
const path = require("path");

const app = express();
const server = http.createServer(app);

const PORT = Number(process.env.SERVER_PORT || 4242);

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "FoodTruckPOS",
    phonepeConfigured: Boolean(process.env.PHONEPE_CLIENT_ID)
  });
});

app.get("/api/products", (_req, res) => {
  res.json([]);
});

app.post("/api/payment/create", (_req, res) => {
  res.status(501).json({
    error: "PhonePe integration is not configured in this scaffold."
  });
});

app.post("/api/payment/callback", (_req, res) => {
  res.status(501).json({
    error: "PhonePe callback handler requires merchant configuration."
  });
});

app.get("/admin", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`FoodTruckPOS listening on ${PORT}`);
});
