module.exports = function ordersRouter(_deps) {
  // Order API implementation point.
};
