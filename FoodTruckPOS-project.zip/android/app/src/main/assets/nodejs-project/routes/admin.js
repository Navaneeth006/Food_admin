module.exports = function adminRouter(_deps) {
  // PIN/session/admin API implementation point.
};
