module.exports = function productsRouter(_deps) {
  // Product/menu API implementation point.
};
