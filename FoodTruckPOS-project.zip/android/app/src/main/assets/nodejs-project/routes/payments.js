module.exports = function paymentsRouter(_deps) {
  // PhonePe payment API implementation point.
};
