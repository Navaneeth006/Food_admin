# FoodTruckPOS release rules
